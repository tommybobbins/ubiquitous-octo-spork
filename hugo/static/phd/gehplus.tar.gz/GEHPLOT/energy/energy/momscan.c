#include <stdio.h>
#include <math.h>
main()
{
 int i,j,k,t,n,l,m,mean;
 unsigned int count;
 float prob[2][1000],setup[5][1000];
 float start,end,divup,diff,momdaug;
 float maximum,newstart;
 FILE *probs,*out,*params;

 if ((params = fopen("mompram","rt")) == NULL)
  {
    printf("mompram could not be opened\n");}
 if ((probs = fopen("gehmom.dat","rt")) == NULL)
  {
    printf("gehmom.dat could not be opened\n");
  }
 if ((out = fopen("sorted.out","wt")) == NULL)
   {
    printf("sorted.out could not be opened\n");
  }
   fscanf(params,"%g \n %g \n %g",&start,&end,&momdaug);
   printf("start= %g \t %s \t %g \t %s \t %g\n",start,"end =",end,"daughter mom=",momdaug);
  
     for (j=0; j<1500; ++j){
       fscanf(probs,"%f\t%f\t%f\t%f",&setup[1][j],&setup[2][j],&setup[3][j],&setup[4][j]);}

     l=m=maximum=0;
     for (j=0;j<1500&&(setup[4][j]>300||j<100);++j){
       if ((setup[3][j]-setup[3][j-1])>(setup[3][j+2]-setup[3][j+1])){
	 ++l;
	  maximum=(setup[3][j]) ;}
       if ((setup[3][j]-setup[3][j-1])<(setup[3][j+2]-setup[3][j+1])&&setup[3][j]<maximum){
	 ++m;}

        t=j+1;
;}
     printf("last line of scan %d\n",t);
     printf("One side of the peak is %d\n",l);
     printf("Other side of the peak is %d\n",m);
     diff=end-start;
     divup=(diff)/t;
     mean=abs((l+m)/2);
     printf("Mean peak %d \n",mean);
     printf("Each point is separated from the next by %g kgms-1\n",divup);
     newstart=momdaug-((mean*diff)/t);
     printf("Scan will commence from %g kgms-1\n",newstart);
     for(i=0;i<t;++i){
       fprintf(out,"%g\t%f\n",(newstart+(divup*i)),setup[3][i]);
     ;}




}
















