#include <stdio.h>
#include <math.h>
main()
{
 int i,j;
 unsigned int count;
 float width[2][500],lenscanmm,mome,momf;
   float delmass,enev,jouleev,q,starting,end,amukg;
 float delmom,delen,masskg,mass70geh,t,enwaven,vaccn,momdaug;
 float enjoule,momlen,energy,ev,beamen,ensquare,T,Tcm;
 FILE *probs,*out;

 if ((probs = fopen("width.dat","rt")) == NULL)
  {
    printf("width.dat could not be opened\n");
  }
 if ((out = fopen("delenergy.out","wt")) == NULL)
   {
    printf("delenergy.out could not be opened\n");
  }
 for (i=1;i<30;++i){
   fscanf(probs,"%f",&t);
   width[1][i]=t;}

	 amukg=1.66054e-27;
	 ev=8065.5;
	 q=1.60219e-19;
	 vaccn=1425.0;
	 beamen=q*vaccn;
	 printf("Acceleration energy = %g\n",beamen);
	 jouleev=1.60219e-19;
	 mass70geh=70.0;
	 momdaug=7.22622e-21;
	 lenscanmm=210;
	 starting = 8.32408501;
	 end =  8.45651318;
	 printf("%f\t%f\n",starting,end);

	   momf=starting*sqrt(2)*sqrt(beamen)*sqrt(amukg);printf("T = %12.12e ev\n",T);
	   mome=end*sqrt(2)*sqrt(beamen)*sqrt(amukg);
	   momlen=mome-momf;
	   printf("%e\t",momf);
	   printf("%e\n",mome);
	   printf("length mom scan= %g \n",momlen);
	   printf("Momentum of daughter is calculated to be:%g\n",momdaug);
	   printf("*****************************************************");
	 for (i=1;i<30;++i){
	   printf("\nwidth in mm= %f\n",width[1][i]);
	   delmom=(width[1][i]/lenscanmm)*momlen;
	   printf("momentum spread in lab frame= %g\n",delmom);
	   energy=((delmom)/(mass70geh*amukg))*momdaug;
	   printf("energy spread = %12.12e\n",energy);
	   enwaven=(energy/q)*ev;
	   printf("energy spread = %12.12e cm-1\n",enwaven);
	   ensquare=pow((energy/beamen),2);
	   printf("enspread/beamen squared %12.12e \n",ensquare);
	   T=70*ensquare*vaccn/(16*1.008);
	   printf("T = %12.12e ev\n",T);
	   Tcm=T*ev;
	   printf("T = %12.12e cm-1\n",Tcm);

	 }
}
















