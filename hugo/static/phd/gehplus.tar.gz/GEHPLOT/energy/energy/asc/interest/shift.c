#include <stdio.h>
#include <math.h>
main(){
 int i,j,k;

 float setup[2][1400],addit;
 FILE *probs,*out,*params;

 if ((probs = fopen("g0mscan.i","rt")) == NULL)
  {
    printf("g0mscan.i could not be opened\n");
  }
 if ((out = fopen("sorted.out","wt")) == NULL)
   {
    printf("sorted.out could not be opened\n");
  }
 if ((params = fopen("params","rt")) == NULL){  
      printf("params could not be opened\n"); 
   } 

/*      printf(" hello world \n"); */

     fscanf(params,"%g\n%d",&addit,&k);
     printf("%g\n %d",addit,k);
     printf("addit= %g",addit);
     
      for (j=1; j<k+1; j++){ 
        fscanf(probs,"%g\t %e",&setup[0][j],&setup[1][j]);} 
 

     
     for (j=1;j<k+1;j++){ 
  fprintf(out,"%g\t%e\n",setup[0][j]+addit,setup[1][j]);} 
     ;}





















