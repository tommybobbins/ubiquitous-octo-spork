#include <stdio.h>
#include <math.h>
main()
{
 int i,j,k;

 float setup[2][1400],addit;
 FILE *probs,*out,*params;


     for (j=1; j<851; ++j){
       printf ("1700.000\n");}
;}





















