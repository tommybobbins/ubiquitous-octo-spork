#include <stdio.h>

main(){
 int i,j,k;

 float setup[3][870];
 FILE *fitted,*out,*fitting;

 if ((fitted = fopen("g0m2410d.cmp","rt")) == NULL)
  {
    printf("g0m2410d.cmp could not be opened\n");
  }
 if ((out = fopen("sorted.out","wt")) == NULL)
   {
    printf("sorted.out could not be opened\n");
  }
 if ((fitting = fopen("g0m2410d.nst","rt")) == NULL){  
      printf("g0m2410d.nst could not be opened\n"); 
   } 
 

  for (i=1;i<862;++i){ 
      fscanf(fitted,"%g\n",&setup[2][i]);} 
     
       for (i=0;i<862; i++){   
          fscanf(fitting,"%g\t%e",&setup[0][i],&setup[1][i]);}   
 

     
     for (j=0;j<861;++j){ 
  fprintf(out,"%g\t%e\t%e\n",setup[0][j],setup[1][j],setup[2][j]);} 
     ;}





















