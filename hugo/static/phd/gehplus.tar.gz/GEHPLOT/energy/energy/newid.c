#include <stdio.h>
#include <math.h>
main()
{
 int i,j;
 unsigned int count;
 float width[2][500],lenscanmm,mome,momf;
 float start,end;
   float delmass,enev,jouleev,q,starting,amukg;
 float delmom,delen,masskg,mass70geh,t,enwaven,vaccn,momdaug;
 float enjoule,momlen,energy,ev,beamen,ensquare,T,Tcm;
 FILE *probs,*out;

 if ((probs = fopen("width.dat","rt")) == NULL)
  {
    printf("width.dat could not be opened\n");
  }
 if ((out = fopen("delenergy.out","wt")) == NULL)
   {
    printf("delenergy.out could not be opened\n");
  }
 for (i=1;i<30;++i){
   fscanf(probs,"%g",&t);
   width[1][i]=t;}

	 amukg=1.66054e-27;
	 ev=8065.5;
	 q=1.60219e-19;
	 vaccn=1425.0;
	 beamen=q*vaccn;
	 printf("Acceleration energy = %g\n",beamen);
	 jouleev=1.60219e-19;
	 mass70geh=69.92425;
	 momdaug=7.24438e-21;



	 starting = 8.2491555;
	 end =  8.3899133;
	 printf("%f\t%f\n",starting,end);

	   momf=starting*sqrt(2)*sqrt(beamen)*sqrt(amukg);
	   mome=end*sqrt(2)*sqrt(beamen)*sqrt(amukg);
	   momlen=mome-momf;
	   printf("%e\t",momf);
	   printf("%e\n",mome);
	   printf("length mom scan= %g \n",momlen);
	   printf("Momentum of daughter is calculated to be:%g\n",momdaug);
	   printf("*****************************************************\n");
	 for (i=1;i<30;++i){
	   printf("delmom= %g\n",width[1][i]);
	   delmom=width[1][i];
	   printf("momentum spread in lab frame= %g\n",delmom);
	   energy=((delmom)/(mass70geh*amukg))*momdaug;
	   printf("energy spread = %12.12e\n",energy);
	   enwaven=(energy/q)*ev;
	   printf("energy spread = %12.12e cm-1\n",enwaven);
	   ensquare=pow((energy/beamen),2);
	   printf("enspread/beamen squared %12.12e \n",ensquare);
	   T=mass70geh*ensquare*vaccn/(16*1.007825);
	   printf("T = %12.12e ev\n",T);
	   Tcm=T*ev;
	   printf("T = %12.12e cm-1\n",Tcm);
	   printf("\n");
	 }
}
















