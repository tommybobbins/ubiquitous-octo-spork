#include <stdio.h>
#include <math.h>
main()
{
 int i,j;
 float setup[1000];

for (i=1;i<877;++i){
  scanf("%g",&setup[i]);
  printf("%g\n",setup[i]+2600);
}

}













