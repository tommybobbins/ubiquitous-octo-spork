#include <stdio.h>
#include <math.h>
main()
{
 int i,j;
 float prob[2][15000];
 float a,unshift,shift,pkshift;
 float mass,massamu,voltage,energy,speed,voverc,c;
 double shifter;
 FILE *probs,*out,*params;
 if ((params = fopen("doppler.dat","rt")) == NULL)
  {
    printf("doppler.dat could not be opened\n");}
 if ((probs = fopen("doppg4h.inp","rt")) == NULL)
  {
    printf("doppg4h.inp could not be opened\n");
  }
 if ((out = fopen("doppler.out","wt")) == NULL)
   {
    printf("doppler.out could not be opened\n");
  }

   fscanf(params,"%f\n%f",&voltage,&massamu);
     for (j=0; j<15000; j++){
     	 fscanf(probs,"%f\t%f",&prob[0][j],&prob[1][j]);
	 }
	 
	   printf("voltage equals\t %f %s",voltage,"volts\n");

	 mass=massamu*1.660566E-27;
	 printf("mass equals\t %f %s",massamu,"amu\n");
	 printf("mass equals\t %g %s",mass,"kg\n");
	 c=2.99792458e+8;
	 energy=voltage*1.602189e-19;
	 printf("Energy equals\t %g %s",energy,"J\n");
	 speed=sqrt(2*energy/mass);
	 printf("Speed equals \t %f16 %s",speed,"ms-1\n");
	 voverc=speed/c;
	 shifter=sqrt((1-voverc)/(1+voverc));
	 printf("Shift peaks by factor \t %1.16e \n",shifter);
	 for (i=0;i<15000;++i){
	 pkshift=prob[0][i]*shifter;
	 fprintf(out,"%f\t%f\n",pkshift,prob[1][i]);}
}
















